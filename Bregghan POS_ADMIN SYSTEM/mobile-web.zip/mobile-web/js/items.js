var cart = [];
const product_items = {
    "978020137961": {
        "name": "C2 Red",
        "code": "C2R5HML",
        "price": 30.00,
        "image": "c2-red.png"
    },
    "100036219082": {
        "name": "Absolute Mineral Water",
        "code": "AMW500ML",
        "price": 10.00,
        "image": "absolute.png"
    },
    "538276340019": {
        "name": "Coke Mismo",
        "code": "CMSMO10",
        "price": 15.00,
        "image": "coke.png"
    },
    "889300173211": {
        "name": "Nissin cup nooble Chicken",
        "code": "NCNCHCKN",
        "price": 35.00,
        "image": "nissin-chicken.png"
    },
}